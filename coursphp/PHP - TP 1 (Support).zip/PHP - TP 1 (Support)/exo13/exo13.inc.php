<?php
$db_host="localhost";
$db_name="tests";
$db_user="tests";
$db_pass="tests";

$civilite=array('H'=>'M.', 'F'=>'Mme./Mlle.');

#ici la connexion à la BDD


?>